#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include "threads/thread.h"
#include "vm/mmap.h"

// 전역 파일 시스템 락
extern struct lock filesys_lock;

void syscall_init (void);

void check_valid_uaddr (const void *uaddr);

void halt (void);
void exit (int status);
tid_t exec (const char *cmd_line);
int wait (tid_t pid);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);

int fibonacci (int n);
int max_of_four_int (int a, int b, int c, int d);

bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
void close (int fd);
int filesize (int fd);
void seek (int fd, unsigned position);
unsigned tell (int fd);

mapid_t sys_mmap(int fd, void *addr);
void sys_munmap(mapid_t mapping);

#endif /* userprog/syscall.h */
