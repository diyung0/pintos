#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "lib/kernel/console.h"
#include "threads/synch.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "vm/page.h"
#include "vm/stack.h"
#include "vm/mmap.h"

static void syscall_handler (struct intr_frame *);
static int allocate_fd (struct file *file);
static struct file *get_file (int fd);

// 파일 디스크립터 범위 상수
#define FD_MIN 2
#define FD_MAX 128
#define STDIN 0
#define STDOUT 1

struct lock filesys_lock;

void
syscall_init (void) 
{
  lock_init(&filesys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void
check_valid_uaddr (const void *uaddr) 
{
  
  if (uaddr == NULL || !is_user_vaddr (uaddr)) {
    exit (-1);
  }

  struct thread *t = thread_current();

  void *page = pg_round_down(uaddr);

  // 이미 로드된 페이지
  if (pagedir_get_page(t->pagedir, page) != NULL) {
    return;
  }

  // SPT에 있는 페이지
  struct page_table_entry *pte = spt_find(&t->spt, page);
  if (pte != NULL) {
    return;
  }

  exit (-1);
}

static int allocate_fd (struct file *file) {
  struct thread *t = thread_current();
  if(t->next_fd >= FD_MAX) {
    return -1;
  }
  int fd = t->next_fd;
  t->fd_table[fd] = file;
  t->next_fd++;
  return fd;
}

static struct file *get_file (int fd) {
  struct thread *t = thread_current();
  if (fd < FD_MIN || fd >= FD_MAX) {
    return NULL;
  }
  return t->fd_table[fd];
}

static void preload_buffer_write(void *buffer, unsigned size) {
  if (buffer == NULL || size == 0) {
    return;
  }
  
  struct thread *t = thread_current();
  
  for (void *upage = pg_round_down(buffer); 
       upage <= pg_round_down(buffer + size - 1); 
       upage += PGSIZE) {
    
    // SPT 확인
    struct page_table_entry *pte = spt_find(&t->spt, upage);
    
    // writable이 아니면 exit
    if (pte != NULL && !pte->writable) {
      exit(-1);
    }
    
    // 읽기만으로 페이지 로드
    volatile uint8_t dummy = *(uint8_t*)upage;
    (void)dummy;
  }
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  check_valid_uaddr (f->esp);

  uint32_t *esp = (uint32_t *) f->esp;
  uint32_t syscall_num = *esp;

  switch (syscall_num) {
    case SYS_HALT:
      halt ();
      break;

    case SYS_EXIT:
      check_valid_uaddr (esp + 1);
      exit (*(esp + 1));
      break;
    
    case SYS_EXEC:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr ((void *) *(esp + 1));
      f->eax = exec ((const char*) *(esp + 1));
      break;

    case SYS_WAIT:
      check_valid_uaddr (esp + 1);
      f->eax = wait(*(esp + 1));
      break;

    case SYS_READ:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      check_valid_uaddr (esp + 3);
      {
        int fd = *(esp + 1);
        void *buffer = (void *) *(esp + 2);
        unsigned size = *(esp + 3);

        check_valid_uaddr (buffer);
        if (size > 0) check_valid_uaddr (buffer + size - 1);

        f->eax = read (fd, buffer, size);
      }
      break;

    case SYS_WRITE:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      check_valid_uaddr (esp + 3);
      {
        int fd = *(esp + 1);
        const void *buffer = (const void *) *(esp + 2);
        unsigned size = *(esp + 3);

        check_valid_uaddr (buffer);
        if (size > 0) check_valid_uaddr (buffer + size - 1);

        f->eax = write (fd, buffer, size);
      }
      break;

    case SYS_FIBONACCI:
      check_valid_uaddr (esp + 1);
      f->eax = fibonacci(*(esp + 1));
      break;

    case SYS_MAX_OF_FOUR_INT:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      check_valid_uaddr (esp + 3);
      check_valid_uaddr (esp + 4);
      f->eax = max_of_four_int(*(esp + 1), *(esp + 2), *(esp + 3), *(esp + 4));
      break;

    case SYS_CREATE:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      check_valid_uaddr ((void *) *(esp + 1));
      f->eax = create ((const char *) *(esp + 1), *(esp + 2));
      break;

    case SYS_REMOVE:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr ((void *) *(esp + 1));
      f->eax = remove ((const char *) *(esp + 1));
      break;

    case SYS_OPEN:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr ((void *) *(esp + 1));
      f->eax = open ((const char *) *(esp + 1));
      break;

    case SYS_CLOSE:
      check_valid_uaddr (esp + 1);
      close (*(esp + 1));
      break;

    case SYS_FILESIZE:
      check_valid_uaddr (esp + 1);
      f->eax = filesize (*(esp + 1));
      break;

    case SYS_SEEK:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      seek (*(esp + 1), *(esp + 2));
      break;

    case SYS_TELL:
      check_valid_uaddr (esp + 1);
      f->eax = tell (*(esp + 1));
      break;

    case SYS_MMAP:
      check_valid_uaddr (esp + 1);
      check_valid_uaddr (esp + 2);
      f->eax = sys_mmap(*(esp + 1), (void *) *(esp + 2));
      break;

    case SYS_MUNMAP:
      check_valid_uaddr (esp + 1);
      sys_munmap(*(esp + 1));
      break;

    default:
      exit (-1);
      break;
  }
}

void halt() {
  shutdown_power_off();
}

void exit(int status) {
  thread_current()->exit_status = status;
  thread_exit();
}

tid_t exec(const char *cmd_line) {
  return process_execute(cmd_line);
}

int wait(tid_t tid) {
  return process_wait(tid);
}

int read (int fd, void *buffer, unsigned size) {
  if (fd == STDIN) {
    uint8_t *buf = (uint8_t *) buffer;
    for (unsigned i = 0; i < size; i++) {
      buf[i] = input_getc ();
    }
    return size;
  }
  if (fd >= 2) {
    struct file *f = get_file(fd);
    if (f == NULL) {
      exit(-1);
    }
    preload_buffer_write(buffer, size);

    lock_acquire(&filesys_lock);
    int result = file_read (f, buffer, size);
    lock_release(&filesys_lock);
    return result;
  }
  return -1;
}

int write (int fd, const void *buffer, unsigned size) {
  if(fd == STDOUT) {
    preload_buffer_write(buffer, size);

    putbuf(buffer, size);
    return size;
  }
  if (fd >= 2) {
    struct file *f = get_file(fd);
    if (f == NULL) {
      exit(-1);
    }

    lock_acquire(&filesys_lock);
    int result = file_write (f, buffer, size);
    lock_release(&filesys_lock);
    return result;
  }
  return -1;
}

int fibonacci (int n) {
  if (n <= 1) return n;
  int prev = 0, cur = 1;
  for(int i = 2; i<= n; i++) {
    int next = prev + cur;
    prev = cur;
    cur = next;
  }
  return cur;
}

int max_of_four_int (int a, int b, int c, int d) {
  int ans = a;
  if(b > ans) ans = b;
  if(c > ans) ans = c;
  if(d > ans) ans = d;
  return ans;
}

bool create (const char *file, unsigned initial_size) {
  lock_acquire(&filesys_lock);
  bool result = filesys_create (file, initial_size);
  lock_release(&filesys_lock);
  return result;
}

bool remove (const char *file) {
  lock_acquire(&filesys_lock);
  bool result = filesys_remove (file);
  lock_release(&filesys_lock);
  return result;
}

int open (const char *file) {
  lock_acquire(&filesys_lock);
  struct file *f = filesys_open (file);
  lock_release(&filesys_lock);

  if (f == NULL) {
    return -1;
  }
  int fd = allocate_fd (f);
  return fd;
}

void close (int fd) {
  struct file *f = get_file (fd);
  if (f == NULL) {
    exit(-1);
  }
  lock_acquire(&filesys_lock);
  file_close (f);
  lock_release(&filesys_lock);
  thread_current()->fd_table[fd] = NULL;
}

int filesize (int fd) {
  struct file *f = get_file (fd);
  if (f == NULL) {
    exit(-1);
  }
  lock_acquire(&filesys_lock);
  int result = file_length (f);
  lock_release(&filesys_lock);
  return result;
}

void seek (int fd, unsigned position) {
  struct file *f = get_file (fd);
  if (f == NULL) {
    exit(-1);
  }
  lock_acquire(&filesys_lock);
  file_seek (f, position);
  lock_release(&filesys_lock);
}

unsigned tell (int fd) {
  struct file *f = get_file (fd);
  if (f == NULL) {
    exit(-1);
  }
  lock_acquire(&filesys_lock);
  unsigned result = file_tell (f);
  lock_release(&filesys_lock);
  return result;
}

mapid_t sys_mmap(int fd, void *addr) {
  if (fd == 0 || fd == 1 || addr == 0 || pg_ofs(addr) != 0 || !is_user_vaddr(addr)) {
    return -1;
  }

  struct file *file = get_file(fd);
  if (file == NULL) {
    return -1;
  }

  lock_acquire(&filesys_lock);
  off_t file_len = file_length(file);
  lock_release(&filesys_lock);
  if (file_len == 0) {
    return -1;
  }

  if (check_mmap_overlap(addr, file_len)) {
      return -1;
  }

  lock_acquire(&filesys_lock);
  struct file *reopened_file = file_reopen(file);
  lock_release(&filesys_lock);
  if (reopened_file == NULL) {
    return -1;
  }

  bool writable = true; 
  mapid_t mapid = mmap_insert(reopened_file, fd, addr, file_len, writable);
  return mapid;
}

void sys_munmap(mapid_t mapping) {
  mmap_munmap(thread_current(), mapping);
}